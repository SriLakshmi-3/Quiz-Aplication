package admin_user.service;

import admin_user.model.Result;

import java.util.List;

public interface ScoreService {
    void saveScore(String score, String loggedInUser, String subject, int questions);

    List<Result> getHistroyForUser(String loggedInUser);

    void updateUserName(String userName, String fullname);
}
